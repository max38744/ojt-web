async function fetchChartData(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching chart data:', error);
    return null;
  }
}

async function renderChart() {
  const ctx = document.getElementById("myAreaChart");

  const url = `/data_response?resource=${encodeURIComponent(window.selectedResource)}`;
  const chartData = await fetchChartData(url);
  console.log("Chart data:", chartData);

  if (chartData) {
    const myLineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: chartData.labels,
        datasets: [{
          label: "Sessions",
          lineTension: 0.3,
          backgroundColor: "rgba(2,117,216,0.2)",
          borderColor: "rgba(2,117,216,1)",
          pointRadius: 5,
          pointBackgroundColor: "rgba(2,117,216,1)",
          pointBorderColor: "rgba(255,255,255,0.8)",
          pointHoverRadius: 5,
          pointHoverBackgroundColor: "rgba(2,117,216,1)",
          pointHitRadius: 50,
          pointBorderWidth: 2,
          data: chartData.values,
        }],
      },
      options: {
        scales: {
          xAxes: [{
            time: { unit: 'date' },
            gridLines: { display: false },
            ticks: { maxTicksLimit: 7 },
          }],
          yAxes: [{
            ticks: { min: 0, max: 100, maxTicksLimit: 5 },
            gridLines: { color: "rgba(0, 0, 0, .125)" },
          }],
        },
        legend: { display: false },
        onClick: (event, elements) => {
          if (elements.length > 0) {
            const elementIndex = elements[0]._index;
            const label = chartData.labels[elementIndex];
            const value = chartData.values[elementIndex];

            console.log('Clicked data point:', { label, value });

            if (typeof updateChartData === "function") {
              updateChartData(label, value);
              updateBarChart(label, value);
            } else {
              console.error("updateChartData or updateBarChart not defined.");
            }
          }
        },
      },
    });
  } else {
    console.error("Chart data is not available.");
  }
}

renderChart();

/*!
    * Start Bootstrap - SB Admin v7.0.7 (https://startbootstrap.com/template/sb-admin)
    * Copyright 2013-2023 Start Bootstrap
    * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
    */
    // 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    window.selectedResource = "resource_1"; // 전역 변수 설정
    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }
});




// 모든 차트를 업데이트하는 함수
async function updateAllCharts() {
    //const pirData = await fetchChartData();
    //const barData = await fetchChartData();
    renderChart();
    renderPieChart();
    renderBarChart();
    //if (barData) renderBarChart(barData);
    //if (pirData) renderPieChart(pirData);
}
  

// 드롭다운 변경 이벤트 리스너
document.getElementById("resourceSelector").addEventListener("change", (event) => {
  window.selectedResource = event.target.value; // 선택된 값 저장
  console.log(`Selected resource: ${window.selectedResource}`);

  // 차트 데이터 새로 가져오기 (모든 차트 업데이트)
  updateAllCharts();
});

